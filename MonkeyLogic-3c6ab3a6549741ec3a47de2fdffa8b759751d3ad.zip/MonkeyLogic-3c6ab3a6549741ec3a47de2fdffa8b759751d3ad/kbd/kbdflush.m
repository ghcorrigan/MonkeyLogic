function kbdflush_mexgen ()
% KBDFLUSH  Flush the keyboard buffer.
%
% KBDFLUSH will clear all unprocessed keystrokes that have been saved
% since the last call to KBDINIT.
%
% See also KBDINIT, KBDRELEASE

% Mexgen generated this file on Wed Nov  6 12:05:31 2013
% DO NOT EDIT!

kbdmex (2);
