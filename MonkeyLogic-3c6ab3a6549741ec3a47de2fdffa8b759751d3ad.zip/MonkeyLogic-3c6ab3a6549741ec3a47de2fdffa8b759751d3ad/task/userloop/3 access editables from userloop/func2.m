function param = func2()

param.probability = 0;

end
