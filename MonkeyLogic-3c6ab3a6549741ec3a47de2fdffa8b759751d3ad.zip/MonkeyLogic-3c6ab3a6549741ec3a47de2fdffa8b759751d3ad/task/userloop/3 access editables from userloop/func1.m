function param = func1()

param.probability = 1;

end
