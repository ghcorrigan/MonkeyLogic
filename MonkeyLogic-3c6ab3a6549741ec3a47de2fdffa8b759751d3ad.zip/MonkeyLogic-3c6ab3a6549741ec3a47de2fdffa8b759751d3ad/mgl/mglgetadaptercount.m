function count = mglgetadaptercount()
%count = mglgetadaptercount()
%
%   May 4, 2016     Written by Jaewon Hwang (jaewon.hwang@hotmail.com)

count = mdqmex(0);
