function result = mglsubjectscreenexists()

result = mdqmex(35);
