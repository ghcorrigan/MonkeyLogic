function mglshow(id)

mglactivategraphic([0 id],[false true]);
mglrendergraphic;
mglpresent;
