function mglsetcontrolscreenshow(show)

mdqmex(41,logical(show));
