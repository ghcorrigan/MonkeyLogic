function tf = ischannel(s) %#ok<INUSD>
    tf = false;
end