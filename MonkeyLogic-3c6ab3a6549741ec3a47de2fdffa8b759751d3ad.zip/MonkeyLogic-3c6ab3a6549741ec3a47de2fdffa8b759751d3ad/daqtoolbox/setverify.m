function actual = setverify(obj, prop, value)

set(obj, prop, value);
actual = get(obj, prop);
