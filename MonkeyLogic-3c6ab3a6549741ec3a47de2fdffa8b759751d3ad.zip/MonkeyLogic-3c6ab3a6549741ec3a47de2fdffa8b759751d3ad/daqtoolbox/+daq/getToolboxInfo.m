function [name,ver] = getToolboxInfo()

name = 'NIMH daqtoolbox';
ver = '(May 4, 2017 build 51)';
